package com.censhare;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CenshareDemo {

	static String wordOccur="";
	public static void main(String[] args) {
		String str = "1.All over the world, leading companies and brands place their trust in Censhare in integrating and automating their communication."
				+ "2.Our customer and project portfolio encompasses virtually all sectors and company sizes."
				+"3.These activities are driven and advanced by more than 270 employees across the world, with subsidiaries in Germany, Switzerland, UK, France, USA, the Netherlands, Sweden and India."
				+"4.We are working with highly motivated, competent colleagues coming from more than 30 different nations using cutting-edge technologies across cultures";
	
		String[] dotSplit =str.split("\\.");
		ArrayList<String> lineRevMap = new ArrayList<>();
		 for(int ind=0; ind< dotSplit.length; ind++) {
			 if(!isNumber(dotSplit[ind])) {
				 String line =dotSplit[ind];
				 parseData(line, lineRevMap);
			 }
		 }
		
		 //print line in reverse as given excepted output
		 for(int i=0; i<4; i++) {
			 if(i==2) {
				System.out.println(lineRevMap.get(i+1));
			 }else if(i==3) {
				 System.out.println(lineRevMap.get(i-1));
			 }else {
				 System.out.println(lineRevMap.get(i));
			 }
			 
		 }
		 
		//Max Occurence of word
		String[] splitStr =  str.split(" ");
	    Long max = maxOccurenceWord(splitStr);
		System.out.println("Max occurrence -"+wordOccur+" (" +max+")");
		
		
	}

	private static void parseData(String str, List<String> lineRevMap) {
		
		String[] splitStr = str.split(" "); 
		String result = new String();
		 for(int i=splitStr.length-1; i>=0; i--) {
			 String word = splitStr[i];
			 isStartwithNumber(word);
			 if(countryMap().containsKey(word)) {
				String code =  countryMap().get(word);
				 result += code+" ";
			 }else {
				 result += word+" ";
			 }
		 }
		 lineRevMap.add(result);
		
	}

	private static boolean isNumber(String word) {
		return word.equals("1") || word.equals("2") || word.equals("3") || word.equals("4");
	}
	
	private static boolean isStartwithNumber(String word) {
		 if(word.startsWith("1") || word.startsWith("2") || word.startsWith("3") || word.startsWith("4")) {
			  word = word.substring(1)+"\n";
			  return true;
		  }
		return false;
	}

	private static HashMap<String, String> countryMap() {
		HashMap<String, String> codeMap = new HashMap<>();
		codeMap.put("Germany", "DE");
		codeMap.put("Switzerland", "CH");
		codeMap.put("UK", "UK");
		codeMap.put("France", "US");
		codeMap.put("USA", "DE");
		codeMap.put("Netherlands", "NL");
		codeMap.put("Sweden", "SE");
		codeMap.put("India", "IN");
		return codeMap;
	}

	private static Long maxOccurenceWord(String[] strArr) {

		Map<String, Long> frqCount = Arrays.asList(strArr).stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		List<Long> valueList = frqCount.entrySet().stream().map(o -> o.getValue()).collect(Collectors.toList()).stream()
				.sorted().collect(Collectors.toList());
		Long max = valueList.get(valueList.size() - 1);
		wordOccur= frqCount.entrySet().stream().filter(o->o.getValue()==max).map(e->e.getKey()).findAny().get();

		return max;
	}

}
