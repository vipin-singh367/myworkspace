package com.pep.dsa.linkedlist;

public class LLTest {

	public static void main(String[] args) {
		MyLinkedList ll = new MyLinkedList();
		ll.addLast(10);
		ll.addLast(20);
		ll.addLast(30);
		ll.addLast(40);
		
//		ll.display(ll);
//		System.out.println(ll.size());
		System.out.println("------------------------");
		
		ll.addFirst(123);
		ll.addFirst(133);
		ll.addFirst(143);
		ll.display(ll);
		System.out.println(ll.size());
		//System.out.println(ll.getFirst());
		//System.out.println(ll.getLast());
		//System.out.println(ll.getAt(4));
		ll.addAt(4,500);
		ll.display(ll);
		System.out.println(ll.size());
		
		/*MyLinkedList ll2 = new MyLinkedList();
		ll2.addLast(100);
		ll2.display(ll2);
		System.out.println(ll2.size());
		ll2.removeFirst();
		ll2.display(ll2);
		System.out.println(ll2.size());
		System.out.println("------------------------");*/
	}

}
