package com.pep.dsa.linkedlist;

/*
 * Operations of LiinkedList---
 * addFirst, addLast, addAt
 * getFirst, getLast, getAt
 * removeFirst, removeLast, removeAt
 */



public class MyLinkedList {

	Node head;
	Node tail;
	int size;

	void addFirst(int data) {
		if (size == 0) {
			Node nn = new Node();
			nn.data = data;
			nn.next = null;
			head = tail = nn;
			size++;
		} else {
			Node nn = new Node();
			nn.data = data;
			nn.next = head;
			head = nn;
			size++;

		}
	}
	
	void addLast(int data) {
		Node nn = new Node();
		nn.data = data;
		nn.next = null;
		if (size == 0) {
			head = nn;
			tail = nn;
		} else {
			tail.next = nn;
			tail = nn;
		}
		size++;
	}
	
	void addAt(int indx, int data) {

		if (size < indx || indx < 0) {
			System.out.println("Invalid Argumnt...");
		}
		if (indx == 0) {
			addFirst(data);
		} else if (size - 1 == indx) {
			addLast(data);
		} else {

			Node temp = head;
			for (int i = 1; i < indx; i++) {
				temp = temp.next;
			}

			Node nextNode = temp.next;
			Node newNode = new Node();
			newNode.data = data;
			newNode.next = nextNode;
			temp.next = newNode;
			size++;

		}

	}

	void removeFirst() {
		if (size == 0) {
			System.out.println("LinkedList is empty!!!");
		} else if (size == 1) {
			head = null;
			tail = null;
			size--;
		} else {
			head = head.next;
			size--;
		}
	}
	
	void removeLast() {
		if (size == 0) {
			System.out.println("LinkedList is empty!!!");
		} else if (size == 1) {
			head = null;
			tail = null;
			size--;
		} else {
			head = head.next;
			size--;
		}
	}
	
	int getFirst() {
		return head.data;
	}
	
	int getLast() {
		return tail.data;
	}
	
	int getAt(int index) {
		int data = -1;
		if(size==0) {
			System.out.println("List is empty...");
			return -1;
		}
		if (index < 0 ||size < index) {
			System.out.println("Invalid Argument...");
			return -1;
		}
		
		if(size==1) {
			return getFirst();
			
		}else if(size==index-1) {
			return getLast();
		} else {
			Node temp = head;
			for (int i = 1; i < index; i++) {
				temp = temp.next;
			}
			return temp.data;
		}
	}
	
	

	int size() {
		return size;
	}

	void display(MyLinkedList linkedList) {
		Node temp = linkedList.head;
		while (temp != null) {
			System.out.print(temp.data+" ");
			temp = temp.next;
		}
		System.out.println();

	}

}

class Node{
	int data;
	Node next;
	
}
