package com.logical;

import java.util.Scanner;

public class AnyBaseToDecimal {

	public static void main(String[] args) {
	    
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int b = sc.nextInt();
		int result = getAnyBaseToDecimal(n, b);
		System.out.println(result);
	}

	private static int getAnyBaseToDecimal(int n, int b) {
		int result = 0;
		int counter = 0;
		while (n != 0) {
			int rem = n % 10;
			// pow fn put 10 for decimal input
			result = result + rem * (int) Math.pow(b, counter);
			n /= 10;
			counter++;
		}

		return result;
	}

}
