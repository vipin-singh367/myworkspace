package com.logical;

import java.util.Scanner;

public class InverseNumber {

	public static void main(String[] args) {

		 
		 Scanner sc = new Scanner(System.in);
		 int n = sc.nextInt();
		 
		 int len = n != 0 ?  0:1;
		 int temp=n;
		 while(temp != 0){
		     temp /=10;
		     len++;
		 }
		 System.out.println(len);
		 int result=0;
		 for(int no=1; no<=len; no++){
		     int rem= n%10;
		     n /=10;
		     result = result + no*(int)Math.pow(10, rem-1);
		     
		     
		 }
		 System.out.println(result);
		  
		  
		 
	}

}
