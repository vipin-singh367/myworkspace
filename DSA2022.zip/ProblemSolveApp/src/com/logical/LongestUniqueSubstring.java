package com.logical;

import java.util.HashSet;

public class LongestUniqueSubstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "dvdf";

		HashSet<Character> hs = new HashSet<>();
		int max = 0;
		int start = 0;
		int count = 0;
		while (start < str.length()) {
			char ch = str.charAt(start);
			if (hs.contains(ch)) {
				count = count-1;
				hs.remove(ch);
			} 
			hs.add(ch);
			start++;
			count++;
			if (count > max) {
				max = count;
			}
		}

		System.out.println(max);
	}

}
