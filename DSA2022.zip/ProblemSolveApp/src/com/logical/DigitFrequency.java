package com.logical;

import java.util.Scanner;

public class DigitFrequency {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int findDigit = sc.nextInt();

		int frqCount = 0;
		while (n != 0) {
			int rem = n % 10;
			n /=10;
			if (rem == findDigit) {
				frqCount++;
			}

		}
		
		System.out.print(findDigit+" frequency count : "+frqCount);

	}

}
