package com.logical;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class TripletSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        Integer A[] = { 1, 4, 45, 6, 10, 8 };
        int sum = 22;
        int arr_size = A.length;
       
       tripleteSum(A, arr_size, sum);

	}

	private static boolean tripleteSum(Integer[] A, int arr_size, int sum) {

		 HashSet<Integer> s = new HashSet<Integer>();
	        List<Integer> list = Arrays.asList(A);
	        for(int i=0; i<arr_size-1; i++) {
	        	int target = sum-A[i];
	        	for(int j=i+1; j<arr_size; j++) {
	        		Integer tag = target-A[j];
	        		if(list.contains(tag)) {
	        			System.out.println(A[i]+" "+A[j]+" "+tag+" = "+sum);
	        			return true;
	        		}
	        	}
	        	
	        }
		return false;
	}

}
