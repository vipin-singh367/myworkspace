package com.logical.edgeverve;

public class FirstUniqueCharacter {

	public static void main(String[] args) {
		
		String str = "statistics";
		
		for(int i = 1; i<=str.length(); i++) {
			char ch = str.charAt(i);
			int firstIndex = str.indexOf(ch);
			int lastIndex = str.lastIndexOf(ch);
			if(firstIndex == lastIndex) {
				System.out.println(ch +" : "+(firstIndex+1));
				break;
			}
		}
		
		//System.out.println("No Unique char : -1");
	}

}
