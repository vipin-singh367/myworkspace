package com.logical;

public class CheckPrime {

	public static void main(String[] args) {
	/*	checkPrimeOptimized(1);
		checkPrimeOptimized(7);
		checkPrimeOptimized(27);
		checkPrimeOptimized(70);
		checkPrimeOptimized(17);
		checkPrimeOptimized(20);*/
	/*	int fact = checkPrimeOptimized(20);
		
		if (fact == 0) {
			System.out.println(20 + " - Prime");
		} else {
			System.out.println(20 + " - NOT Prime");
		}*/
		
		checkPrimeAllinRange(10, 20);
		
		
	}
	
	//Complexity -  O(n)
	public static void checkPrime(int no) {
		int fact = 0;
		for (int i = 2; i < no; i++) {
			if (no % i == 0) {
				fact++;
			}
		}
		if (fact == 0) {
			System.out.println(no + " - Prime");
		} else {
			System.out.println(no + " - NOT Prime");
		}
	} 
	
	// O(sqrt root n)
	public static int checkPrimeOptimized(int no) {
		int fact = 0;
		for (int i = 2; i*i <= no; i++) {
			if (no % i == 0) {
				fact++;
				break;
			}
		}
		return fact;
	} 
	
	
public static void checkPrimeAllinRange(int low, int high) {
	
	while(low<=high) {
		int fact = checkPrimeOptimized(low);
		if(fact==0) {
			System.out.println(low + " is Prime");
		}
		low++;
	}
	
	
}	

}
