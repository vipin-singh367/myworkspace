package com.logical;

import java.util.Scanner;

public class GcdLcm {

	public static void main(String[] args) {
	     
	     Scanner sc = new Scanner(System.in);
	     int num1 = sc.nextInt();
	     int num2 = sc.nextInt();
	     
	     int dvd = num1 > num2 ? num1 : num2;
	     int div = num1 < num2 ? num1 : num2;
	    
	     while(dvd%div != 0){
	     int r = dvd%div;
	     dvd=div;
	     div=r;
	     }
	     
	     int gcd=div;
	     int lcm = gcd != 0 ? (num1*num2)/gcd : num1*num2;
	     
	     System.out.println(gcd);
	     System.out.println(lcm);
	     
	     }

}
