package com.logical.arrays;

import java.util.Arrays;

public class PositivePrefix {
	
	
	public static void main(String[] args) {
		int[] arr= {-6,-12,-80,33,2,4,3,-10};
		Arrays.sort(arr);
		int idx=-1;
		for(int i=0; i< arr.length; i++) {
			if(arr[i] >= 0) {
				idx=i;
				System.out.println(arr[i]);
				break;
			}
				
		}
		
		int[]  result =  new int[arr.length];
		for(int i=0; i<result.length-(idx+1); i++) {
			result[i]=arr[i];
		}
		
				
	}

}
