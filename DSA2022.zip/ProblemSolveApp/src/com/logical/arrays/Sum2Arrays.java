package com.logical.arrays;

import java.util.Scanner;

//
public class Sum2Arrays {

	public static void main(String[] args) {
	    // write your code here
	      Scanner sc= new Scanner(System.in);
	  
	 int a1 =  sc.nextInt();
	  int[] arr1 = new int[a1];
	  for(int i=0; i<arr1.length; i++){
	      arr1[i]= sc.nextInt();
	  }
	  
	  int a2 =  sc.nextInt();
	  int[] arr2 = new int[a2];
	  
	   for(int i=0; i<arr2.length; i++){
	      arr2[i]= sc.nextInt();
	  }
	  
	  
	 int size=arr1.length+1;
	 if(arr2.length>arr1.length){
	     size = arr2.length+1;
	 }
	  
	  
	 int[] ans = new int[size];
	 int i = arr1.length-1;
	 int j = arr2.length-1;
	 int k = ans.length-1;
	 int carry=0;
	  
	  while(k>=0){
	     int sum = carry;
	     if(i>=0){
	        sum+= arr1[i];
	     }
	     
	     if(j>=0){
	        sum+= arr2[j];
	     }
	     int q= sum/10;
	     int r = sum%10;
	     ans[k]=r;
	     carry=q;
	     
	     i--;
	     j--;
	     k--;
	      
	  }
	  
	  for(int t=0; t<ans.length; t++){
	   if(t==0 && ans[t]==0){
	       
	   }else{
	       System.out.println(ans[t]);
	   }
	      
	  }
	    
	 }

}
