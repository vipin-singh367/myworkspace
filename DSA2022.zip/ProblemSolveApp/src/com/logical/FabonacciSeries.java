package com.logical;

import java.util.Scanner;

public class FabonacciSeries {

	public static void main(String[] args) {

	      Scanner sc = new Scanner(System.in);
	      int n = sc.nextInt();
	      int first =0;
	      int second =1;
	      System.out.println(first);
	      System.out.println(second);
	      
	      if(n>2){
	      for(int i=1; i<=n-2; i++){
	       int third = first+second;
	       first =second;
	       second =third;
	       System.out.println(third);
	      }
	      }
	      
	      
	   

	}

}
