package com.logical;

import java.util.Scanner;

public class KRotationNumber {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int no = sc.nextInt();
		int KthRotation = sc.nextInt();
		int len = lenthOfNumber(no);
		KthRotation %= len;
		if(KthRotation < 0) {
			KthRotation += len;
		}
			int base = (int)Math.pow(10, KthRotation);
			int rotNo = no%base;
			int q =no/base;
			int result = rotNo * ((int)Math.pow(10, len - KthRotation)) + q;
			
		
		
		System.out.println(result);

	}

	private static int lenthOfNumber(int no) {
		int len  = no != 0 ? 0 : 1;
		int temp =no;
		while(temp != 0) {
			temp /=10;
			len++;
		}
		return len;
	}

}
