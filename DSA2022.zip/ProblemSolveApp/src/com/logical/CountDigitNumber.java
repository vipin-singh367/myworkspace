package com.logical;

import java.util.Scanner;

public class CountDigitNumber {

	public static void main(String[] args) {
	    Scanner sc =  new Scanner(System.in);
	    int n = sc.nextInt();
	    
	    int count= n!=0 ? 0 : 1;
	    while(n!=0){
	        n=n/10;
	        count++;
	    }
	    
	    System.out.println(count);

	}

}
