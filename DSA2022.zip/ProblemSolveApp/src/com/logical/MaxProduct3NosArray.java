package com.logical;

public class MaxProduct3NosArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//int[] arr = {3,2,1,6,10};
		int[] arr = {-2,-1,7,10};
		int max1= Integer.MIN_VALUE;
		int max2= Integer.MIN_VALUE;
		int max3= Integer.MIN_VALUE;
		
		int min1=Integer.MAX_VALUE;
		int min2=Integer.MAX_VALUE;
		
		for (Integer n : arr) {

			if (n > max1) {
				max3 = max2;
				max2 = max1;
				max1 = n;
			} else if (n > max2) {
				max3 = max2;
				max2 = n;

			} else if (n > max3) {
				max3 = n;
			}

			if (n < min1) {
				min2 = min1;
				min1 = n;
			} else if (n < min2) {
				min2 = n;
			}

		}
		
	//	Integer res = Math.max(max1*min1*min2, max1*max2*max3);
	//	System.out.println("Max : "+max1+","+max2+","+max3+" MIN :"+min1+","+min2+" Result =>"+res);
		
		Integer maxNe = max1*min1*min2;
		Integer maxPo = max1*max2*max3;
		if(maxNe>maxPo) {
			System.out.println(min1+"*"+min2+"*"+max1+" Result =>"+maxNe);
		}else {
			System.out.println(max1+"*"+max2+"*"+max3+" Result =>"+maxPo);
		}
		
		
	}

}
