package com.logical;

import java.util.Arrays;
import java.util.List;

public class AddTwoArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr1= {2,3,5,6};
		int size1=arr1.length;
		int[] arr2= {3,8,7,8,6};
		int size2=arr2.length;
		
		int max = size1>size2 ? size1 : size2;
		Integer[] ans = new Integer[max];
		int carry=0;
		for (int i = 0; i < max; i++) {
			int f = 0;
			int s = 0;
			if (i < size1) {
				f = arr1[size1 - (i + 1)];
			}
			if (i < size2) {
				s = arr2[size2 - (i + 1)];
			}

			int sum = s + f + carry;
			int no = sum % 10;
			carry = sum / 10;
			ans[max - (i + 1)]=no;
		}
		
		
		System.out.println(Arrays.asList(ans));
		

	}

}
