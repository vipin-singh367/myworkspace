package com.opentext;

import java.util.Scanner;

public class NumberSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*N=26=>2+6= 8-------8 find next sum for 8
		N=27=>2+7=9----Invalid
		N=28=>2+8=10----Invalid
		N=29=>2+9=11----Invalid
		N=35=>3+5=8----VALID ans is 35
		*/
		Scanner sc= new Scanner(System.in);
		int n = sc.nextInt();
		int temp=n;
		int sum=sumOfDigit(temp);
		int nextNum=n;
		int nextSum=0;
		while(sum !=nextSum) {
			nextNum +=1;
			nextSum =sumOfDigit(nextNum);
		}
		
		System.out.println(nextNum);

	}
	
	public static int sumOfDigit(int temp) {
		int sum = 0;
		while (temp != 0) {
			int no = temp % 10;
			sum += no;
			temp /= 10;
		}
		return sum;
	}

}
