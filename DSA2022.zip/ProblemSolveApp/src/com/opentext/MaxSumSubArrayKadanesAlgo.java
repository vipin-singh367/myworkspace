package com.opentext;

public class MaxSumSubArrayKadanesAlgo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {5,2,-2,-5,8,-3,9};
		int curMax=arr[0];
		int sumArr=arr[0];
		for (int i = 1; i < arr.length; i++) {
			if (curMax > arr[i]) {
				curMax += arr[i];
			} else {
				curMax = arr[i];
			}

			if (sumArr < curMax) {
				sumArr = curMax;
			}

		}
		
		System.out.println(sumArr);
	}

}
