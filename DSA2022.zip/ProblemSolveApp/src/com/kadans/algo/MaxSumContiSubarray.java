package com.kadans.algo;

//Kandans Algorithm
public class MaxSumContiSubarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//maxsum is index 2 to 6 which will op=7
		int[] arr = {-2,-3,4,-1,-2,1,5,-3}; 
		int size = arr.length;
		int maxSofar=Integer.MIN_VALUE;
		int max=0;
		
		for (int i = 0; i < size; i++) {
			max += arr[i];
			if (maxSofar < max) {
				maxSofar = max;
			}
			if (max < 0) {
				max = 0;
			}
		}
		
		System.out.println(maxSofar);
		

	}

}
