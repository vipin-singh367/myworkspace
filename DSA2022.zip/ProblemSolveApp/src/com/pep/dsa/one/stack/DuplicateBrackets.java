package com.pep.dsa.one.stack;

import java.util.Stack;

public class DuplicateBrackets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String exp1="((a+b)+(c+d))"; // No use less brackets here return false 
		String exp="(a+b)+((c+d))"; // Needless bracket here return true
		Stack<Integer> st = new Stack<>();
		for (int i = 0; i < exp.length(); i++) {
			char ch = exp.charAt(i);
			if(ch==')') {
				if(st.peek()=='(') {
					System.out.println("true");
					return;
				}else {
					while(st.peek() !='(' ) {
						st.pop();
					}
					st.pop();
				}
				
			}else{
				st.push(ch-0);
			}
			
		}
		
		System.out.println("false");
		

	}

}
