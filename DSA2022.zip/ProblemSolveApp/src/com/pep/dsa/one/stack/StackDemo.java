package com.pep.dsa.one.stack;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer> st = new Stack<>();
		st.push(10);
		st.push(20);
		st.push(30);
		st.push(40);
		st.push(50);
		System.out.println("Stack data - "+st);
		System.out.println("Stack data peek- "+st.peek()); // top data -50
		System.out.println("Stack data after peek - "+st);
		System.out.println("Stack data size - "+st.size());//size of stack
		System.out.println("Stack data pop- ");
		while(st.size() != 0) {
			System.out.print(st.pop()+" ");
		}
		System.out.println("Stack data after pop - "+st.size());

	}

}
