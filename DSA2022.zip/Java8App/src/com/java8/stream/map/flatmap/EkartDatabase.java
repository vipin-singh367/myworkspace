package com.java8.stream.map.flatmap;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EkartDatabase {

	public static List<Customer> getAll(){
		return Stream.of(
				new Customer(101, "Vipin", "vipin.singh367@gmail.com", Arrays.asList("9452852417","8318951460")),
				new Customer(102, "John", "john@gmail.com", Arrays.asList("5523232323","83189513333")),
				new Customer(104, "Smith", "smith@gmail.com", Arrays.asList("21221212","44443333")),
				new Customer(103, "Peter", "peter@gmail.com", Arrays.asList("8888222111","11111211"))
				).collect(Collectors.toList());
	}
	
}
