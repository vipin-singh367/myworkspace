package com.java8.stream.map.flatmap;

import java.util.List;
import java.util.stream.Collectors;

public class MapFlatMapDemo {

	public static void main(String[] args) {
		
		List<Customer> customers = EkartDatabase.getAll();
		
		// get List emails
		// cust -> cust.getEmail() -> one to one mapping, Data Transformation
		List<String> emails = customers.stream().map(cust -> cust.getEmail()).collect(Collectors.toList());
		System.out.println(emails);
		
		// To get phone numbers list
		List<List<String>> phoness = customers.stream().map(cust->cust.getPhoneNumbers()).collect(Collectors.toList());
		System.out.println(phoness);//[[9452852417, 8318951460], [5523232323, 83189513333], [21221212, 44443333], [8888222111, 11111211]] <- Non Flatted data
		
		// cust->cust.getPhoneNumbers() -> One to Many, Flatted data
		List<String> phones = customers.stream().flatMap(cust->cust.getPhoneNumbers().stream()).collect(Collectors.toList());
		System.out.println(phones); //[9452852417, 8318951460, 5523232323, 83189513333, 21221212, 44443333, 8888222111, 11111211] <-Flatted data

		
		
	}

}
