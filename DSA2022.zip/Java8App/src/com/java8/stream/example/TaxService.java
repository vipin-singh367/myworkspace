package com.java8.stream.example;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TaxService {

	
	public static List<Employee> evaluateTax(String input) {
		if (input.equalsIgnoreCase("tax")) {
			return Database.getEmployees().stream().filter(t -> t.getSalary() > 40000).collect(Collectors.toList());
		} else {
			return Database.getEmployees().stream().filter(t -> t.getSalary() < 40000).collect(Collectors.toList());
		}
	}
	
	public static Employee get2HighestSalary() {
		
		return Database.getEmployees().stream().sorted(Comparator.comparing(Employee :: getSalary).reversed()).skip(1).findAny().get();
	}
	
	public static void main(String[] args) {
		//System.out.println(evaluateTax("ntax"));
		
		System.out.println(get2HighestSalary());
	}
	
}
