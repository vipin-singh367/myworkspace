package com.java8.stream.example;

import java.util.ArrayList;
import java.util.List;

public class Database {
	
	public static List<Employee> getEmployees(){
		
		List<Employee> empList = new ArrayList<>();
		
		empList.add(new Employee(101, "Vipin Singh", "IT", 500000));
		empList.add(new Employee(102, "Abhay Singh", "CSE", 5000));
		empList.add(new Employee(103, "Aman Singh", "IT", 100000));
		empList.add(new Employee(104, "Ritik Singh", "ECE", 800000));
		empList.add(new Employee(105, "Nitin Singh", "MCA", 360000));
		empList.add(new Employee(106, "Anubhav Singh", "MBA", 43000));
		empList.add(new Employee(107, "Shivam Singh", "MBA", 23000));
		empList.add(new Employee(108, "Shivam Pandey", "Civil", 2000));
		
		return empList;
	}

}
