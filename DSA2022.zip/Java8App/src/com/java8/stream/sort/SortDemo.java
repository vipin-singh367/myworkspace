package com.java8.stream.sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.java8.stream.example.Database;
import com.java8.stream.example.Employee;

public class SortDemo {

	public static void main(String[] args) {
	
		List<Integer>  list = new ArrayList<>();
		list.add(100);
		list.add(50);
		list.add(1010);
		list.add(50000);
		list.add(110);
		list.add(10);
		
		//Collections.sort(list); //Assending
		//Collections.reverse(list); // desending
		//System.out.println(list);
		//list.stream().sorted().forEach(t-> System.out.println(t));  //Assending 
		//list.stream().sorted(Comparator.reverseOrder()).forEach(o->System.out.println(o)); //desending
		List a= list.stream().sorted().collect(Collectors.toList());
		System.out.println(a);
		
		List<Employee> empList = Database.getEmployees();
		//empList.stream().sorted(Comparator.comparing(Employee :: getSalary)).forEach(System.out :: print); //sorted by Salary
		//Sort by Name and Salary
		empList.stream().sorted(Comparator.comparing(Employee :: getName).thenComparing(Employee :: getSalary)).forEach(System.out :: println);
	
	}
	
	
	
	
	
}
