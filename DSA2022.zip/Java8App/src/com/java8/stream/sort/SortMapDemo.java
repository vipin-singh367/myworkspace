package com.java8.stream.sort;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.java8.stream.example.Employee;

public class SortMapDemo {

	public static void main(String[] args) {
		HashMap<String, Integer> hm  = new HashMap<>();
		hm.put("eight", 8);
		hm.put("four", 4);
		hm.put("ten", 10);
		hm.put("two", 2);
		hm.put("seven", 7);
		//hm.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out :: println); //keys based sorting
		//hm.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out :: println); //values based sorting
		
		
		/*TreeMap<Employee, Integer> tm = new TreeMap<>(new Comparator<Employee>() {
			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getSalary() - o2.getSalary();
			}
		});*/
		
		TreeMap<Employee, Integer> tm = new TreeMap<>((o1, o2)-> o1.getSalary() - o2.getSalary());
		
		tm.put(new Employee(101, "Vipin Singh", "IT", 500000), 50);
		tm.put(new Employee(102, "Abhay Singh", "CSE", 5000), 100);
		tm.put(new Employee(103, "Aman Singh", "IT", 100000), 300);
		tm.put(new Employee(104, "Ritik Singh", "ECE", 800000),400);
		tm.put(new Employee(105, "Nitin Singh", "MCA", 360000), 350);
		tm.put(new Employee(106, "Anubhav Singh", "MBA", 43000), 150);
		tm.put(new Employee(107, "Shivam Singh", "MBA", 23000), 800);
		tm.put(new Employee(108, "Shivam Pandey", "Civil", 2000), 700);
		tm.put(new Employee(111, "Abhay Pandey", "ECE", 500000), 100);
		
		//System.out.println(tm);
		//Sort by Name  assending
		//tm.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee :: getName).reversed())).forEach(System.out :: println);
		
		//Sort by Name desending
		//tm.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee :: getName).reversed())).forEach(System.out :: println);
		
		//Sort by Name & dept
		tm.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee :: getName).thenComparing(Comparator.comparing(Employee :: getDept)))).forEach(System.out :: println);
		
		Integer max=tm.entrySet().stream().max(Map.Entry.comparingByValue()).get().getValue();
		System.out.println(max);
		
		

	}

}
