package com.java8.stream.range;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class RangeDemo {

	public static void main(String[] args) {
		
		Integer[] arr = {8,11,55,11,4,1,7,45,22,3,4,45};
		List<Integer> list = Arrays.asList(arr);
		List<Integer> res = IntStream.range(0, list.size()-1).filter(i->list.get(i)<list.get(i+1)).mapToObj(list :: get).collect(Collectors.toList());
		System.out.println(res);

	}

}
