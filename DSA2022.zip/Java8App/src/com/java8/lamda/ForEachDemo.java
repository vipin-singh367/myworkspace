package com.java8.lamda;

import java.util.ArrayList;
import java.util.HashMap;

public class ForEachDemo {

	public static void main(String[] args) {

		ArrayList<String> list = new ArrayList<>();
		list.add("Vipin");
		list.add("Nitin");
		list.add("Ritik");
		list.add("Aman");
		list.add("Rishabh");
		list.add("Vivek");
		list.add("Prem");
		
		//list.stream().forEach(t->System.out.println(t));
		//list.stream().filter(t->t.startsWith("Viv")).forEach(k -> System.out.println(k));
		
		HashMap<String, String> map = new HashMap<>();
		map.put("101", "Vipin Singh");
		map.put("102", "Nitin Singh");
		map.put("103", "Ritik Singh");
		map.put("104", "Aman Singh");
		map.put("106", "Rishabh Singh");
		map.put("105", "Abhay Singh");
		
		//map.forEach((key, value) -> System.out.println(key+":"+value));
		
		//map.entrySet().stream().forEach(obj -> System.out.println(obj));
		
		map.entrySet().stream().filter(j->j.getValue().startsWith("R")).forEach(o->System.out.println(o));
		
		
	}

}
