package com.java8.lamda;

public interface FnInterfaceDemo {

	//void switchOn();
	//void printRank(int rank);
	int subtraction(int n1, int n2);
}

