package com.java8.lamda;

public class Calculator {


		public static void main(String[] args) {
			// () -> {body}
			//FnInterfaceDemo fnDemo = () -> System.out.println("SwitchON");
			//fnDemo.switchOn();
			
			/*FnInterfaceDemo fnDemo = (rank) -> System.out.println("Rank is "+rank);
			fnDemo.printRank(21);*/
			
			/*FnInterfaceDemo fnDemo  = (n1, n2) -> {
				return n2-n1;
			};*/
			//OR
			FnInterfaceDemo fnDemo  = (n1, n2) -> {
				if(n2<n1) {
					throw new RuntimeException("First Number is less than second");
				}else {
					return n2-n1;
				}
				
			};
			//OR
			//FnInterfaceDemo fnDemo  = (n1, n2) ->n2-n1;
			
			
			System.out.println("Substraction :  "+fnDemo.subtraction(100, 50));
		}
		
}
