package com.java8.optional;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.java8.stream.map.flatmap.Customer;
import com.java8.stream.map.flatmap.EkartDatabase;

/* There  are 3 ways to create Optional class =  empty()- return Optional.empty Object, 
of(value) - if have value return value otherwise NPE, ofNullable() - if have value retun value otherwise*/
public class OptionalDemo {

	public static void main(String[] args) throws Exception {

		Customer customer  = new Customer(101, "vipin", "vipin@gmail.com", Arrays.asList("9452852417","8318951460"));
		
		Optional<Object> optionalObj = Optional.empty();
		System.out.println(optionalObj);
		
		//Optional<String> nameOptional = Optional.of(customer.getName());
		//System.out.println(nameOptional);
		
		Optional<String> nameOptional2 = Optional.ofNullable(customer.getName()); // if null return Optional Obj otherwise value(null ?empty() or of())
		/*if(nameOptional2.isPresent()) {
		//System.out.println(nameOptional2); //Optional[Vipins]
		System.out.println(nameOptional2.get()); //Vipins
		}*/
		//System.out.println(nameOptional2.orElse("default Name Nitin")); //if null return else block otherwise vaule
		//System.out.println(nameOptional2.orElseThrow(()-> new IllegalArgumentException("name is empty"))); //if null return else block custom exception
		
		//System.out.println(nameOptional2.map(String :: toUpperCase).orElseGet(()->"default Name Hrithik...."));
		
		getCustomerByName("John");
		
	}
	
	public static Customer getCustomerByName(String inputName) throws Exception {
		
		List<Customer> customers = EkartDatabase.getAll();
		
		Customer customer= customers.stream().filter(obj->obj.getName().equalsIgnoreCase(inputName)).findAny().orElse(new Customer());
		
		return customers.stream().filter(obj->obj.getName().equalsIgnoreCase(inputName))
				.findAny().orElseThrow(() -> new Exception("Name is empty"));
	}

}
