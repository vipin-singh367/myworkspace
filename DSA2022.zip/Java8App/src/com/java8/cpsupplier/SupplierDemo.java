package com.java8.cpsupplier;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		Supplier<String> supplier =  () -> "This test message";
		//System.out.println(supplier.get());
		//List<String> list = Arrays.asList("Vipin", "Sumit"); //print  Vipin
		List<String> list = Arrays.asList(); // print This test message
		System.out.println(list.stream().findAny().orElseGet(supplier));
		
	}
	
}
