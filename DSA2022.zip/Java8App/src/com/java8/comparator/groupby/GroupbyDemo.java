package com.java8.comparator.groupby;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class GroupbyDemo {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("apple", "cat","apple","cat","cat","cat","cat","ball", "apple","cat","dog");

		  Map<String, Long> result = list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		  
		  System.out.println(result);
		  List as = result.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toList());
		  //System.out.println(as);
		  List<Employee> emplist = Employee.getEmployeeList();
		  Map<String, List<Employee>> emailWise = emplist.stream().collect(Collectors.groupingBy(Employee :: getEmail));
		  System.out.println(emailWise);
		  
		 // List aa= emplist.stream().collect(Collectors.groupingBy(Employee :: getEmail)).entrySet().stream().map(o->o.getValue().stream().map(e->e.getName())).collect(Collectors.toList());
			
		  
	}

}
