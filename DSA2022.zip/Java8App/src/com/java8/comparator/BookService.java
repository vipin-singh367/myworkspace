package com.java8.comparator;

import java.util.Collections;
import java.util.List;

public class BookService {

	public List<Book> getBookInSort(){
		List<Book> books = new BookDAO().getBooks();
		/*Collections.sort(books, new Comparator<Book>() {
			@Override
			public int compare(Book o1, Book o2) {
				// TODO Auto-generated method stub
				return o2.getName().compareTo(o1.getName());
			}
		});*/
		
		// Comparator has only one abstract method compareTo, so Comparator is functional Interface
		Collections.sort(books, (o1,o2) -> o1.getName().compareTo(o2.getName()));
		
		return books;  
		
	}
	
	public static void main(String[] args) {
		System.out.println(new BookService().getBookInSort());
	}
}

/*class MyComparator implements Comparator<Book>{

	@Override
	public int compare(Book o1, Book o2) {
		// TODO Auto-generated method stub
		return o1.getName().compareTo(o2.getName());
	}
	
}*/