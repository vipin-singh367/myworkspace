package com.java8.comparator.reduce;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ReduceDemo {

	public static void main(String[] args) {
		
		List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7,8);
		
		Optional<Integer> sum = numbers.stream().reduce(Integer :: sum);
		Optional<Integer> add = numbers.stream().reduce((a,b)-> a+b);
		System.out.println(sum.get()+" = "+add.get());
		int prod = numbers.stream().reduce((a,b)->a*b).get();
		System.out.println(prod);

	}

}
