package com.java8.comparator;

import java.util.ArrayList;
import java.util.List;

public class BookDAO {

	public List<Book> getBooks(){
		ArrayList<Book> books =  new ArrayList<>();
		books.add(new Book(101, "Core Java", 400));
		books.add(new Book(111, "Spring", 230));
		books.add(new Book(108, "Hibernate", 330));
		books.add(new Book(201, "Springboot", 600));
		books.add(new Book(151, "Dbms", 500));
		return books;
	}
}
