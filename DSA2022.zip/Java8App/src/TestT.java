import java.util.Map;
import java.util.TreeMap;

public class TestT {

	public static void main(String[] args) {

        
        String str ="is2 sentence4 This1 a3";
        String[] strArr = str.split(" ");
       TreeMap<Integer, String> res =  new TreeMap<>();
        for(String str1 : strArr){
            int len = str1.length(); 
          //  str1.lastIndexOf(arg0)
            Integer key = Integer.parseInt(str1.substring(len-1, len));
            String value = str1.substring(0, len-1);
            res.put(key,value);
        }
        
        
for(Map.Entry entry :  res.entrySet()){
    System.out.print(entry.getValue() +" ");
}        
        
       
        
        //System.out.println("Hello, World!");
    

	}

}
